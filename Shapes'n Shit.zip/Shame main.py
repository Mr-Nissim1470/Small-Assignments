

import shapes

def main():
    shp1 = shapes.shapes("purple",True)
    shp2 = shapes.shapes("green",False)

    print(shp1)
    print(shp2)

    rect1 = shapes.Rectangle("Blue",True,5.5,4.1)

    print(rect1)

    AreaR = rect1.CalcArea()
    per = rect1.CalcPeri()

    print("Area: ",AreaR)
    print("Perimiter: ", per)

    Circle1 = shapes.Circle("Yellow",False,2.0)

    print(Circle1)

    areac = Circle1.CalcArea()

    peric = Circle1.CalPeri()

    print("Area: ",areac)
    print("Perimiter: ",peric)

    x = 5
    
    comp = compareArea(rect1,Circle1)
    if comp == 1:
        print("Rectangle is smaller")

    elif comp == -1:
        print("Circle is larger")
    else:
        print("both areas are equal")
        
def compareArea(s1,s2):
    if s1.CalcArea()<s2.CalcArea():
        return 1
    elif s1.CalcArea()>s2.CalcArea():
        return -1
    else:
        return 0

   
main()
