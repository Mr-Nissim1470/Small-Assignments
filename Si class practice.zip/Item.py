# Yosef Nahon
# Classes Assignment 11
# Model 1.1

class Item:
    #initialize
    def __init__ (self,P,W,Desc):
        self.__order_price = P
        self.__Ounces = W
        self.__Description = Desc
        self.__quantity = 1

    #Deprivitize
    def get_order_price(self):
        return self.__order_price

    def get_order_weight_in_ounces(self):
        return self.__Ounces
    
    def Get_Description(self):
        return self.__Description

    def Get_quantity(self):
        return self.__quantity
    
    # Make Changable
    def set_quantity(self,Q):
            self.__quantity = Q

    # In case Quantity Changes
    def Set_Full_Price(self):
        Fee = self.__Price * self.__quantity
        return Fee
    
    
    def Set_Full_Ounce(self):
        Whey = self.__Ounces * self.__quantity
        return Whey
    
    
    #Final string
    def __STR__(self):
        Phrase = "$" + self.__order_price + " For " + self.quantity +" "+ self.Description
        return Phrase
