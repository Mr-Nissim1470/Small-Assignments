#Yosef N. Color Mix program model 1 9/4/20 
# The following program will atempt to mix primary colors

def ColorMix():

    Red = "Red"
    Blue = "Blue"
    Yellow = "Yellow"

    Purple = "Purple"
    Orange = "Orange"
    Green = "Green"    
    
    Color1 = input("Name the first primary color you want to mix")

    if Color1[0] == "R" or Color1[0] == "r":
        Color1 = Red
        
    elif Color1[0] == "b" or Color1[0] == "B":
        Color1 = Blue
        
    elif Color1[0] == "y" or Color1[0] == "Y":
        Color1 = Yellow
        
    else:
        print("I don't think that's a primary color...\n Let's try that again")
        ColorMix()

    print("You chose ",Color1," for the first color" )
    
    Color2 = input("Name the second primary color you want to mix")
    

    if Color2[0] == "R" or Color2[0] == "r":
        Color2 = Red
        
    elif Color2[0] == "b" or Color2[0] == "B":
        Color2 = Blue
        
    elif Color2[0] == "y" or Color2[0] == "Y":
        Color2 = Yellow
        
    else:
        print("I don't think that's a primary color...\n we're going to have to do this all over again")
        ColorMix()

    print("You chose ",Color2," for the second color" )

    RedBlue = "Purple"
    BlueRed = "Purple"
    BlueYellow = "Green"
    YellowBlue = "Green"
    YellowRed = "Orange"
    RedYellow = "Orange"

    Mixture = Color1 + Color2

    if Mixture == "RedBlue" or Mixture == "BlueRed":
        Mixture = "Purple"
        
    elif Mixture == "BlueYellow" or Mixture == "YellowBlue":
        Mixture = "Green"

    elif Mixture == "RedYellow" or Mixture == "YellowRed":
        Mixture = "Orange"

    else:
        print("Bru you just mixed the same color twice",Color1,"+",Color2,"equals more",Color2,"Dummy \n Pick 2 DIFFERENT primary colors this time" )
        ColorMix()
        
    print("Mixing",Color1,"with",Color2,"Makes",Mixture)


ColorMix()

    
